<?php require_once('../include/Session.php');?>
<?php require_once('../include/Functions.php');?>
<?php echo AdminAreaAccess(); ?>
<?php include('admin.header.php') ?>
<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Student</title>
</head>
<body>
	<link rel="stylesheet" type="text/css" href="style.css">
<div>
			<h2 class="center">INSERT STUDENT DETAILS</h2>
			
</div>
<div class="container">
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
    <div>
				    Full Name:<input type="text" name="fullname" placeholder="Enter student's Full name" required>
				    ID:<input type="text" name="roll" placeholder="Enter ID" >
				    Intake:<input type="number" name="standard" placeholder="Enter Intake" required>
				    Location: <input type="text" name="city" placeholder="Enter Location" required><br>
				    Parents Contact Number:<input type="text" name="pphone" placeholder="Enter Parent Phone Number" required>
				    Image:<input type="file" class="form-control" name="simg" required>
				  </div>
  	<div>
        <input type="submit" name="submit" value="SUBMIT"> 
    </div>
  </form>
</div>


<?php include('../footer.php') ?>

<?php 

	if (isset($_POST['submit'])) {
		if (!empty($_POST['roll']) && !empty($_POST['fullname'])) {
		
			include ('../dbcon.php');
			$roll=$_POST['roll'];
			$name=$_POST['fullname'];
			$city=$_POST['city'];
			$pphone=$_POST['pphone'];
			$standard=$_POST['standard'];
			include('ImageUpload.php');

			$sql = "INSERT INTO `student`( `rollno`, `name`, `city`, `pcontact`, `standard`,`image`) VALUES ('$roll','$name','$city','$pphone',$standard,'$imgName')";

			$run = mysqli_query($conn,$sql);

			if ($run == true) {
				
				?>
				<script>
					alert("Data Inserted Successfully");
				</script>
				<?php
			} else {
				echo "Error : ".$sql."<br>". mysqli_error($conn); 
			}
		} else {
				?>
				<script>
					alert("Please insert atleast roll no. and fullname");
				</script>
				<?php
		}


	}

 ?>
</body>
</html>
