
<?php require_once('../include/Session.php');?>
<?php require_once('../include/Functions.php');?>
<?php echo AdminAreaAccess(); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="admin/style.css">
                <header>
                        WELCOME TO BUBT INFORMATION SYSTEM
                </header>
    <div class="topnav">
        <a class="active" href="http://localhost/sms/index.php">Home</a>
        <a href="http://localhost/sms/about%20us.php">About Us</a>
        <span style="float: right;"><a href="http://localhost/sms/admin/logout.php">Log Out</a></span>

    </div><br><br><br>


    <h2 class="center">
        WELCOME TO ADMIN DASHBOARD 
    </h2>
        <div class="center">  
                <a class="block" href="addstudent.php">INSERT STUDENT DETAILS </a><br><br><br>
                <a class="block" href="updatestudent.php">EDIT STUDENT DETAILS</a><br><br><br>
                <a class="block" href="deletestudent.php">DELETE STUDENT DETAILS</a>
        </div>
</body>
</html>

<br><br><br><br><br><br>
<?php include('../footer.php') ?>
