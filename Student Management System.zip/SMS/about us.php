<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<head>
  <title>About Us</title>
    <header>
            BUBT STUDENT INFORMATION SYSTEM
    </header>
</head>

      <div class="topnav">
          <a class="active" href="index.php">Home</a>
          <a href="about us.php">About Us</a>
          <a onclick="myFunction()">Dark Mode</a>
          <span style="float: right;"><a href="login.php">Admin Login</a></span>
      </div>
        <div class="parallax">
        </div>

            <div style="height:300px;background-color:white;font-size:36px">
      <p class="design">Meet our team of<br><span style="font-style: italic;">creators & designers</span></p>
      <p style="text-align: center;color: #000;"><span style="font-weight: bold; color: #30A7FF">Legends' Empire</span> team leads web & mobile development community through blogs, open source, videos and meetups.<br>
      We value open source, learning, remote work & open communication</p>
          </div>

        <div class="parallax">
        </div>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="images/shoumik.png" width="400" height="400">
      <div class="container">
        <h2>Md. Sadman Muhtasim Billah</h2>
        <p class="title">Crew Member</p>
        <p>Hey, I'm Shoumik. I am a person who is positive about every aspect of life. There are many things I like to do, to see, and to experience.<br>
        ~I often break rules and make mistakes; because I only get to live once !</p>
        <p><a href="https://www.facebook.com/Shoumik101/"><button class="button">Contact</button></a></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="images/mitul.jpg" width="400" height="400">
      <div class="container">
        <h2>Mitul Das</h2>
        <p class="title">Crew Member</p>
        <p>Some text that describes me lorem ipsum ipsum lorem.</p>
        <p><a href="https://www.facebook.com/arnob.mallick.79"><button class="button">Contact</button></a></p>
        
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img src="images/hridoy.jpg" width="400" height="400">
      <div class="container">
        <h2>Hridoy</h2>
        <p class="title">Crew Member</p>
        <p>Hello, I'm Hridoy.
        <br>I still couldn't figure out my worth. I like the silence and the loneliness. Because in the midst of silence and loneliness, dreams can be arranged at will.</p>
        <p><a href="https://www.facebook.com/arnob.mallick.79"><button class="button">Contact</button></a></p>
      </div>
    </div>
  </div>

  
  <div class="column">
    <div class="card">
      <img src="images/arnob.jpg" width="400" height="400">
      <div class="container">
        <h2>Arnob</h2>
        <p class="title">Crew Member</p>
        <p>Hello, I'm Arnob. Finding a reason to smile, cherish, to be happy, to live and to love <br>& <br>I 💜 photography</p>
        <p><a href="https://www.facebook.com/arnob.mallick.79"><button class="button">Contact</button></a></p>
      </div>
    </div>
  </div>
</div>
<h1>Our Skills</h1>

<p>HTML</p>
  <div class="container">
    <div class="skills html">90%</div>
  </div>

<p>CSS</p>
  <div class="container">
    <div class="skills css">80%</div>
  </div>

<p>JavaScript</p>
  <div class="container">
    <div class="skills js">10%</div>
  </div>

<p>PHP</p>
  <div class="container">
    <div class="skills php">30%</div>
  </div><br>

</body>
</html>
<div>
  <script>
function myFunction() {
   var element = document.body;
   element.classList.toggle("dark-mode");
}
</script>

<?php include('footer.php') ?>
    
</div>