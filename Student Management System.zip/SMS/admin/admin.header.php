
<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" type="text/css" href="style.css">
    <head>
        	<header>
                WELCOME TO BUBT INFORMATION SYSTEM
            </header>
<div class="topnav">
  <a class="active" href="http://localhost/sms/index.php">Home</a>
  <a href="http://localhost/sms/about us.php">About Us</a>

  	<span style="float: right;"><a href="http://localhost/sms/admin/logout.php">Log Out</a></span>
    <span style="float: right;"><a href="admindash.php">Dashboard</a></span>

				
</div>
    </head>
    <body>

					
			