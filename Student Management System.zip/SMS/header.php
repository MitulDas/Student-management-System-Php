<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
    <header>
            BUBT STUDENT INFORMATION SYSTEM
    </header>
  
    <div class="topnav">
        <a class="active" href="index.php">Home</a>
        <a href="about us.php">About Us</a>
        <a onclick="myFunction()">Dark Mode</a>  
        <span style="float: right;"><a href="login.php">Admin Login</a></span>
    </div>
        <script>
            function myFunction() {
            var element = document.body;
            element.classList.toggle("dark-mode");
            }
        </script>
</body>
</html>