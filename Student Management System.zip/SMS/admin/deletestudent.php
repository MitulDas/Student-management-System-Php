<?php require_once('../include/Session.php');?>
<?php require_once('../include/Functions.php');?>
<?php echo AdminAreaAccess(); ?>
<?php include('admin.header.php') ?>
<link rel="stylesheet" type="text/css" href="style.css">
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3  jumbotron ">
			<div  style="text-align: center;">
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data" >
					Choose Standard: <select name="standard" class="btn btn-info" style="margin-right: 30px;">					<option>Select</option>
					<option>39</option>
					<option>40</option>
					<option>41</option>
					<option>42</option>
					<option>43</option>
					<option>44</option>
					<option>45</option>
					<option>46</option>
					<option>47</option>
					<option>48</option>
					<option>49</option>
					<option>50</option>
				</select><br><br><br>
				<input type="submit" name="search" value="SEARCH" class="btn btn-success">
			</form>
		</div>
	</div>
</div>	
<table class="table">
	<h2 class="center">Student's Information</h2>
	<tr>
		
		<th>ID</th>
		<th>Full Name</th>
		<th>Location</th>
		<th>Parent Contact Number</th>
		<th>Profile Picture</th>
		
	</tr>
	<?php
		include('../dbcon.php');
		if (isset($_POST['search'])) {
			$standard = $_POST['standard'];
			$sql = "SELECT * FROM `student` WHERE `standard` = '$standard'";
			$result = mysqli_query($conn,$sql);
			if (mysqli_num_rows($result)>0) {
				while ($DataRows = mysqli_fetch_assoc($result)) {
					$Id = $DataRows['id'];
					$RollNo = $DataRows['rollno'];
					$Name = $DataRows['name'];
					$City = $DataRows['city'];
					$Pcontact = $DataRows['pcontact'];
					$ProfilePic = $DataRows['image'];
	?>
	<tr>
		<td><?php echo $RollNo;?></td>
		<td><?php echo $Name; ?></td>
		<td><?php echo $City; ?></td>
		<td><?php echo $Pcontact; ?></td>
		<td><img src="../databaseimg/<?php echo $ProfilePic;?>" alt="img"></td>
		<td><a class="button" style="float: right;" href="deleterecord.php?Delete=<?php echo $Id; ?>&Picture=<?php echo $ProfilePic;?>" >Delete</a></td>
		
	</tr>
	<?php
	
	}
	
	} else {
	echo "<tr><td colspan ='6' class='text-center'>No Record Found</td></tr>";
	}
	}
	?>
	
</table><br>
</div>
<div class="container">
<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<h2><?php echo @$_GET['deleted']; ?></h2>
	</div>
</div>
</div>
<?php include('../footer.php') ?>