<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<footer>
  		<p> All Rights Reserved. © Copyright 2022.</p>
		<pre>Designed by <span style="font-weight:bold; font-size: 15px;">LEGENDS' EMPIRE</span></pre><br>
  	</footer>
</body>
</html>




