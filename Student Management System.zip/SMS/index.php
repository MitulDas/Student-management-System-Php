<?php
include('header.php')
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
</head>
<body>
<div class="center">
    <h2>Student's Information</h2>
        <form action="index.php" method="post">
            <input type="text" name="roll" placeholder="Enter ID Number" style="width: 340px;height: 35px;">
            <span>or<span>
                <select name="standard">
                    <option>SELECT INTAKE</option>
                    <option>39</option>
                    <option>40</option>
                    <option>41</option>
                    <option>42</option>
                    <option>43</option>
                    <option>44</option>
                    <option>45</option>
                    <option>46</option>
                    <option>47</option>
                    <option>48</option>
                    <option>49</option>
                    <option>50</option>
                </select><br><br><br>
            <input type="submit" name="show" value="SEARCH" style="margin-left: 30px;" >
        </form>
</div><br><br><br>
    
    <table class="table">
        <tr>
            <th>ID</th>
            <th>Intake</th>
            <th>Full Name</th>
            <th>Location</th>
            <th>Parents Contact Number</th>
            <th>Profile Picture</th>
        </tr>
    </table><br>

    <?php
    include('dbcon.php');
    if (isset($_POST['show'])) 
    {
        $Standard = $_POST['standard'];
        $RollNo = $_POST['roll'];
        $sql = "SELECT * FROM `student` WHERE `standard` = '$Standard' OR `rollno`='$RollNo'";
        $result = mysqli_query($conn,$sql);
        if (mysqli_num_rows($result)>0) 
        {
            while ($DataRows = mysqli_fetch_assoc($result))    
            {
                $Id = $DataRows['id'];
                $RollNo = $DataRows['rollno'];
                $Name = $DataRows['name'];
                $City = $DataRows['city'];
                $Pcontact = $DataRows['pcontact'];
                $Standard = $DataRows['standard'];
                $ProfilePic = $DataRows['image'];
    ?>
    <table class="table2">
        <tr>
            <td><?php echo $RollNo;?></td>
            <td><?php echo $Standard;?></td>
            <td><?php echo $Name; ?></td>
            <td><?php echo $City; ?></td>
            <td><?php echo $Pcontact; ?></td>
            <td><img src="databaseimg/<?php echo $ProfilePic;?>" alt="img"></td>
        </tr>
    </table>
    <?php
    
            }
        } 

    else {
    echo "<tr><td colspan ='7' class='text-center'>No Record Found</td></tr>";
         }
    }
    ?>
    <div>
        <?php include('footer.php') ?>
    </div>
</body>
</html>
