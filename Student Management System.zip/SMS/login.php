<?php session_start();?>
<?php include('header.php') ?>
<link rel="stylesheet" type="text/css" href="style.css">
<head>
    <title>Login</title>
</head>

            <br><br><br><br><br><br><br><br><br>
            <div class="center">
  <form action="login.php" method="post">
    <div>
        Username:<input type="text" name="user" placeholder=" Enter Username" required>
    </div>
    <div>
        Password:<input type="password" name="password" placeholder="Enter Password" required>
    </div>
    <div>
        <input type="submit" name="login" value="LOGIN"> 
    </div> 
  </form>
</div>
                            
                        
            
            
            <?php
    include ('dbcon.php');

    if (isset($_POST['login'])) {

        $user = $_POST['user'];
        $password = $_POST['password'];
        $qry = "SELECT * FROM admin WHERE username='$user' AND password='$password'";
        
        $run  = mysqli_query($conn, $qry);

       $row = mysqli_num_rows($run);

        if($row > 0) {
         $data = mysqli_fetch_assoc($run);
                    $id= $data['id'];
                    $_SESSION['uid'] = $id;
                    header('location:admin/admindash.php');

           
        } else {
      ?>             
    <script>
        alert('username or password invalid');
        window.open('login.php','_self');
    </script>
    <?php
                   
                }

}
?>
<br><br><br><br><br><br>    
<?php include('footer.php') ?>

